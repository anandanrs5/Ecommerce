// export const ProductList = [
//         {
//             id: 1,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             thumbnail: "https://i.dummyjson.com/data/products/11/thumbnail.jpg",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             id: 2,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             thumbnail: "https://i.dummyjson.com/data/products/49/thumbnail.jpg",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             id: 3,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 0,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             thumbnail: "https://i.dummyjson.com/data/products/3/thumbnail.jpg",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             id: 4,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             thumbnail: "https://i.dummyjson.com/data/products/16/thumbnail.jpg",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/17/thumbnail.jpg",
//             id: 5,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/18/thumbnail.jpg",
//             id: 6,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/19/thumbnail.jpg",
//             id: 7,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 0,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/20/thumbnail.jpg",
//             id: 8,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
           
//             thumbnail: "https://i.dummyjson.com/data/products/14/thumbnail.jpg",
//             id: 9,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/23/thumbnail.jpg",
//             id: 10,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//          {
//             thumbnail: "https://i.dummyjson.com/data/products/54/thumbnail.jpg",
//             id: 11,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/25/thumbnail.jpg",
//             id: 12,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/26/thumbnail.jpg",
//             id: 13,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 0,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/55/thumbnail.jpg",
//             id: 14,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/58/thumbnail.jpg",
//             id: 15,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/31/thumbnail.jpg",
//             id: 16,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/57/thumbnail.jpg",
//             id: 17,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/33/thumbnail.jpg",
//             id: 18,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/34/thumbnail.jpg",
//             id: 19,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/35/thumbnail.jpg",
//             id: 20,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/36/thumbnail.jpg",
//             id: 21,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/37/thumbnail.jpg",
//             id: 22,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/38/thumbnail.jpg",
//             id: 23,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/61/thumbnail.jpg",
//             id: 24,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/40/thumbnail.jpg",
//             id: 25,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },
//         {
//             thumbnail: "https://i.dummyjson.com/data/products/59/thumbnail.jpg",
//             id: 26,
//             title: "perfume Oil",
//             description: "Mega Discount, Impression of A...",
//             price: 13,
//             discountPercentage: 8.4,
//             rating: 4.26,
//             stock: 65,
//             brand: "Impression of Acqua Di Gio",
//             category: "fragrances",
//             images: [
//                 "https://i.dummyjson.com/data/products/11/1.jpg",
//                 "https://i.dummyjson.com/data/products/11/2.jpg",
//                 "https://i.dummyjson.com/data/products/11/3.jpg",
//                 "https://i.dummyjson.com/data/products/11/thumbnail.jpg"
//             ]
//         },

//     ]